#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"
#define TAM 20

int main()
{
    int opcion;
    char auxOP[TAM];
    float OperandoUno;
    float OperandoDos;
    float sum;
    float rest;
    float div;
    float multi;
    int auxN;
    int flag=0;
    int flag2=0;
    long long int fac;
    char respuesta='s';

    system("color 4E");

    do
    {
        menu(flag,flag2,OperandoUno,OperandoDos);
        printf("Ingrese una opcion: ");
        fflush(stdin);
        gets(auxOP);
        auxN=LargoCad(auxOP,1);
        if(auxN==0)
        {
            opcion=atoi(auxOP);

        }
        else
        {
            printf("ERROR\n");

        }
        switch(opcion)
        {
        case 1:
            OperandoUno=ingresarNum(OperandoUno);
            flag=VNum(OperandoUno);
            incorrecto(flag);
            system("pause");
            system("cls");
            break;
        case 2:
            OperandoDos=ingresarNum(OperandoDos);
            flag2=VNum(OperandoDos);
            incorrecto(flag2);
            system("pause");
            system("cls");
            break;

        case 3:
            sum=suma(OperandoUno,OperandoDos);
            if(ValidacionDOS(flag,flag2)==1)
            {
                printf("La suma es: %.2f\n",sum);
            }

            system("pause");
            system("cls");
            break;
        case 4:
            rest=resta(OperandoUno,OperandoDos);
            if(ValidacionDOS(flag,flag2)==1)
            {
                printf("La resta es: %.2f\n",rest);
            }
            system("pause");
            system("cls");
            break;
        case 5:
            if(ValidacionDOS(flag,flag2)==1)
            {

                div=division(OperandoUno,OperandoDos);

                if(div!=0)
                {
                    printf("La divicion es: %.2f\n",div);

                }

            }

            system("pause");
            system("cls");

            break;
        case 6:
            multi=multiplcacion(OperandoUno,OperandoDos);
            if(ValidacionDOS(flag,flag2)==1)
            {
                printf("La multiplicacion es: %.2f\n",multi);
            }

            system("pause");
            system("cls");

            break;
        case 7:
            fac=factorial(OperandoUno);
            if(validarFAC(flag,fac)==1)
            {
                printf("El factorial del Operando numero 1 es: %lld\n",fac);
            }
            else
            {
                 printf("MATH ERROR\n");
            }
            system("pause");
            system("cls");
            break;
        case 8:
            if(flag==1&&flag2==1)
            {
                todasOperaciones(OperandoUno,OperandoDos);
            }
            else
            {
                printf("Ambos numeros son necesesarios realizar las operaciones\n");
            }

            system("pause");
            system("cls");
            break;
        case 9:  respuesta = 'n';
            break;
        default:
            printf("Por favor ingrese una opcion entre 1-9\n");
            system("pause");
            system("cls");
        }


    }
    while(respuesta=='s');


    return 0;
}

