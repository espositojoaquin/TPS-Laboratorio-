
#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"
float suma(float num1,float num2)
{
    float resultado;

    resultado=num1+num2;

    return resultado;
}
float ingresarNum(float num)
{
    int tam=20;
    char aux[tam];
    float raiz;
    int flag=0;

    int largo;
    printf("Por favor ingrese un numero \n");
    fflush(stdin);
    gets(aux);
    largo=LargoCad(aux,tam);
    if(largo==0)
    {
        if(verifNumero(aux)==1)
        {

            num=atof(aux);

        }
        else
        {
            if(verifNumero(aux)==0)
            {
                raiz=2^(1/2);
                num=raiz;

            }

        }

    }
    else
    {
        printf("ERROR\n");
        num=0;

    }
    return num;


}
float resta(float num1,float num2)
{
    float resultado;

    resultado=num1-num2;

    return resultado;
}
float division(float num1,float num2)
{
    float resultado;
    if(num1!=0&&num2!=0)
    {
        resultado=num1/num2;

    }
    else
    {
        printf("No es posible realizar una division por 0\n");

        resultado=0;

    }
    return resultado;

}
float multiplcacion(float num1,float num2)
{
    float resultado;

    resultado=num1*num2;


    return resultado;
}
long long int factorial(float num)
{
    long long int resultado;
    int aux;
    int error=2^(1/2);
    float auxF;
    if(num==0)
    {
        return 1;
    }
    auxF=num;
    aux=(int)num;
    if(auxF==(float)aux)
    {
        resultado=num*factorial(num-1);
    }
    else
    {
        resultado=error;
    }

    return resultado;

}
void todasOperaciones(float num1,float num2)
{
    float sum, res, div,multi;
    long long int fac;
    sum=suma(num1,num2);
    res=resta(num1,num2);
    if(num1!=0&&num2!=0)
    {
        div=division(num1,num2);
    }
    else
    {
        div=2^(1/2);
    }
    multi=multiplcacion(num1,num2);
    fac=factorial(num1);


    printf("\nLa suma es: %.2f ",sum);
    printf("\nLa resta es: %.2f ",res);
    if(div!=2^(1/2))
    {
        printf("\nLa division es: %.2f ",div);
    }
    else
    {
        printf("\nLa division es: MATH ERROR");
    }

    printf("\nLa multiplicacion es: %.2f ",multi);
    if(fac!=2^(1/2))
    {
        printf("\nEl factorial es: %lld \n",fac);
    }
    else
    {
        printf("\nEl factorial es: MATH ERROR\n");
    }

}
void menu(int flag,int flag2,float num,float num2)
{
    if(flag==0&&flag2==0)
    {
        printf("1. Ingresar 1er operando (A=x)\n");
        printf("2. Ingresar 2do operando (B=y)\n");
        printf("3. Calcular la suma (A+B)\n");
        printf("4. Calcular la resta (A-B)\n");
        printf("5. Calcular la division (A/B)\n");
        printf("6. Calcular la multiplicacion (A*B)\n");
        printf("7. Calcular el factorial (A!)\n");
        printf("8. Calcular todas las operaciones\n");
        printf("9. Salir\n");
    }
    else
    {
        if(flag==1&&flag2==0)
        {
            printf("1. Ingresar 1er operando (A= %.2f)\n",num);
            printf("2. Ingresar 2do operando (B=y)\n");
            printf("3. Calcular la suma (A+B)\n");
            printf("4. Calcular la resta (A-B)\n");
            printf("5. Calcular la division (A/B)\n");
            printf("6. Calcular la multiplicacion (A*B)\n");
            printf("7. Calcular el factorial (A!)\n");
            printf("8. Calcular todas las operaciones\n");
            printf("9. Salir\n");

        }
        else
        {
            if(flag==0&&flag2==1)
            {
                printf("1. Ingresar 1er operando (A=x)\n");
                printf("2. Ingresar 2do operando (B= %.2f)\n",num2);
                printf("3. Calcular la suma (A+B)\n");
                printf("4. Calcular la resta (A-B)\n");
                printf("5. Calcular la division (A/B)\n");
                printf("6. Calcular la multiplicacion (A*B)\n");
                printf("7. Calcular el factorial (A!)\n");
                printf("8. Calcular todas las operaciones\n");
                printf("9. Salir\n");
            }
            else
            {
                if(flag==1&&flag2==1)
                {
                    printf("1. Ingresar 1er operando (A= %.2f)\n",num);
                    printf("2. Ingresar 2do operando (B= %.2f)\n",num2);
                    printf("3. Calcular la suma (A+B)\n");
                    printf("4. Calcular la resta (A-B)\n");
                    printf("5. Calcular la division (A/B)\n");
                    printf("6. Calcular la multiplicacion (A*B)\n");
                    printf("7. Calcular el factorial (A!)\n");
                    printf("8. Calcular todas las operaciones\n");
                    printf("9. Salir\n");
                }

            }
        }
    }
}

int ValidacionDOS(int flag,int flag2)
{
    if(flag==1&&flag2==1)
    {
        return 1;
    }
    else
    {
        printf("Ambos numeros son necesesarios realizar la operacion\n");
    }
}

int verifNumero(char cad[])
{
    int tam;
    int i;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]>'9'||cad[i]<'0'&&cad[i]!='.'&&cad[i]!='-')
        {
            retorno=0;
            break;
        }
        else
        {
            retorno=1;
        }
    }
    return retorno;
}
int LargoCad(char cad[],int tam)
{
    int auxNum,retorno;
    auxNum=strlen(cad);
    if(auxNum>tam)
    {
        retorno=1;
    }
    else
    {
        retorno=0;
    }
    return retorno;
}
int VNum(float num)
{
    int flag;
    float raiz=2^(1/2);
    if(num!=raiz)
    {
        flag=1;
    }
    else
    {
        flag=0;

    }
    return flag;

}
void incorrecto(int estado)
{
    if(estado==0)
    {
        printf("MATH ERROR\n");
    }

}
int validarFAC(int flag,long long int fac)
{
    int retorno;
    if(flag==1)
    {
        if(fac!=2^(1/2))
        {
            retorno=1;
        }
        else
        {
            retorno=0;
        }

    }
    else
    {
        retorno=0;
    }
    return retorno;
}
