/** \brief solicita un operando y lo retorna
 * \return Operando  ingresado por el usuario
 */
float ingresarNum(float);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la suma
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
* \return resultado de la suma
*/
float suma(float num1,float num2);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la resta
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
* \return resultado de la resta
*/
float resta(float num1,float num2);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la division
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
* \return resultado de la division
*/
float division(float num1,float num2);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la multiplicacion
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
* \return resultado de la multiplicacion
*/
float multiplcacion(float num1,float num2);
//********************************************************
/** \brief Recibe el operando uno y  calcula el factorial
*  \param Num1 es el Primero operando ingresado por el usuario
* \return resultado del factorial
*/
long long int factorial(float num);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula todas las operaciones
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
* \return resultado de todas las operaciones
*/
void todasOperaciones(float num1,float num2);
//********************************************************
/** \brief va modificando el menu a medida que se van cargando los valores
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag2 se utiliza para saber si fue ingresado o no el segundo operando
* \return el menu correspondiente a los valores cargados
*/
void menu(int flag,int flag2,float num,float num2);
//********************************************************
/** \brief verifica que se hayan cargados ambos valores
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag2 se utiliza para saber si fue ingresado o no el segundo operando
* \return Retorna 1 en caso de hayan cargado ambos valores
*/
int ValidacionDOS(int flag,int flag2);
//********************************************************
/** \brief va modificando el menu a medida que se van cargando los valores
*  \param Cad,es el string mediante el cual es usuario introduce su numero
* \return devuelve el string en forma de un entero
*/

int verifNumero(char cad[]);
//********************************************************
/** \brief verifica que no se desvorde el string
*  \param cad,string introducido por el usuario
*  \param tam,tama�o de string
* \return Retorna 1 en caso de haya un desbordamiento, y 0 si esta dentro del tama�o
*/
int LargoCad(char cad[],int tam);
//********************************************************
/** \brief verifica que el operando sea distinto de 0
*  \param num,operando introducido por el usuario
* \return Retorna 1 en caso de ser distinto y 0 en caso de igualdad
*/
int VNum(float num);
//********************************************************
/** \brief verifica que se hayan cargados valores coherentes
*  \param estado
*/
void incorrecto(int estado);
//********************************************************
/** \brief verifica que el factorial se pueda calcular
*  \param flag,el estado para saber si se ingreso el primer operando
*  \param fac,resultado del factorial
* \return Retorna 1 en caso del que factoreal se pueda calcular  y 0 si no
*/
int validarFAC(int flag,long long int fac);


