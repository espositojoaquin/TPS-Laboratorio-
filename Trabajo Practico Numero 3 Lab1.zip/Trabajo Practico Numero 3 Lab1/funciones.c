#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funciones.h"
#include <string.h>


int verifNumero(char cad[])
{
    int tam;
    int i;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]>'9'||cad[i]<'0')
        {
            retorno=0;
            break;
        }
        else
        {
            retorno=1;
        }
    }
    return retorno;
}
//******************************************************************************************************
void isNumber(char aux[])
{
    while(verifNumero(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//******************************************************************************************************
int verifFloat(char cad[])
{
    int tam;
    int i;
    int cont=0;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]=='.')
        {
            cont++;
        }
        if(cad[i]>'9'&&cad[i]!='.'||cad[i]<'0'&&cad[i]!='.')
        {
            retorno=0;
            break;
        }
        else
        {
            if(cont>1)
            {
                retorno=0;
            }
            else
            {
                retorno=1;
            }

        }
    }
    return retorno;
}
//*******************************************************************************************
void isFloat(char aux[])
{
    while(verifFloat(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//*******************************************************************************************
int EsLetra(char letras[])
{
    int i,retorno;
    int tam=strlen(letras);
    strlwr(letras);

    for(i=0; i<tam; i++)
    {
        if(letras[i]<'a'&&letras[i]!=' '||letras[i]>'z'&&letras[i]!=' ')
        {
            retorno=0;
            break;
        }
        else
        {

            retorno=1;
            letras[0]=toupper(letras[0]);

        }
    }
    return retorno;
}
//*******************************************************************************
void isWord(char aux[])
{
    while(EsLetra(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//*******************************************************************************
int VefAphaandNumber(char aux[])
{
    int retorno;
    int i;
    int tam=strlen(aux);
    for(i=0; i<tam; i++)
    {
        if(aux[i]>' '&&aux[i]<'/'||aux[i]>'9'&&aux[i]<'`'||aux[i]>'z')
        {
            retorno=0;
        }
        else
        {
            retorno=1;
        }

    }

    return retorno;
}
//***************************************************************************
void isAlphaNumber(char aux [])
{
    while(VefAphaandNumber(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//***************************************************************************
int menu(char auxOP[])
{
    int opcion;
    printf("1.Agregar pelicula \n");
    printf("2.Borrar pelicula \n");
    printf("3.Modificar pelicula \n");
    printf("4.Generar pagina web\n");
    printf("5.Listar \n");
    printf("6.Guardar\n");
    printf("7.Salir \n");
    printf("Ingrese una opcion: ");
    setbuf(stdin,NULL);
    scanf("%s",auxOP);
    isNumber(auxOP);
    opcion=atoi(auxOP);
    return opcion;

}
//***********************************************************************************
eMovie * cargarBinario(eMovie *movie, int *cantidad)
{
    FILE* pPelis;
    eMovie* auxMov;
    int index=0;
    int tam=0;

    pPelis = fopen("bin.dat","rb");

    if(pPelis==NULL)
    {
        pPelis=fopen("bin.dat","wb");


        if(pPelis==NULL)
        {
            printf("No se pudo abrir el archivo");
            system("pause");

        }
    }

    while( !feof( pPelis ) )
    {

        fread( (movie+index), sizeof(eMovie), 1, pPelis);
        if(tam==0)
        {
            tam=2;
        }
        else
        {
          tam++;
        }
        auxMov = realloc( movie, sizeof(eMovie)*tam );

        if(auxMov!=NULL)
        {
            movie=auxMov;
        }
        if(feof(pPelis))
        {
            break;
        }

        index++;

    }
    if(index>0)
    {
       *cantidad = index;
    }
    else
    {
        *cantidad=1;
    }




    fclose(pPelis);

    return movie;
}

//***********************************************************************************

int AltaMovie(eMovie *dato,int longitud,int nuevaLongitud)
{

    char seguir='s';
    int i;
    eMovie *Auxmovie;


    if(dato==NULL)
    {
        printf("\n No hay espacio disponible");
    }
    else
    {
        while(seguir=='s')
        {
            printf("\nIngrese el titulo de la Pelicula: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",(dato+longitud-1)->titulo);
            isWord((dato+longitud-1)->titulo);
            printf("Ingrese la duracion de la Pelicula en minutos: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",(dato+longitud-1)->duracion);
            isNumber((dato+longitud-1)->duracion);
            printf("Ingrese el genero de la Pelicula: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",(dato+longitud-1)->genero);
            isWord((dato+longitud-1)->genero);
            printf("Ingrese el link de la Pelicula: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",(dato+longitud-1)->link);
            validarLink((dato+longitud-1)->link);
            printf("Ingrese la descripcion de la Pelicula: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",(dato+longitud-1)->descripcion);
            validarDescripcion((dato+longitud-1)->descripcion);
            printf("Ingrese el puntaje de la Pelicula: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",(dato+longitud-1)->puntaje);
            validarPuntaje((dato+longitud-1)->puntaje);

            (dato+longitud-1)->id=longitud+100;
            printf("\nSu numero de registro de la pelicula es: %d\n",(dato+longitud-1)->id);
            (dato+longitud-1)->estado=1;

            printf("\nDesea ingresar otra pelicula?(s/n) \n");
            seguir=getch();
            if(seguir=='s')
            {
                    longitud++;

                nuevaLongitud=sizeof(eMovie)*longitud;
                Auxmovie=realloc(dato,nuevaLongitud);
                if(Auxmovie!=NULL)
                {
                    dato=Auxmovie;
                }
                else
                {
                    printf("\nNo hay Espacio disponible \n");
                    break;
                }
            }
            else
            {

                return longitud;
            }
        }





    }






}
//****************************************************

void mostrarPeli(eMovie *dato)
{
    printf("\n Titulo: %s \n Descripcion:%s \n Duracion:%s \n Genero:%s \n Link:%s\n Puntaje:%s\n Codigo de film: %d \n",dato->titulo,dato->descripcion,dato->duracion,dato->genero,dato->link,dato->puntaje,dato->id);


}
void mostrarFILMS(eMovie *dato,int tam)
{
    int i;
    int flag=0;
    system("pause");
    system("cls");
    printf("\n\t\tPELICULAS REGISTRADAS");
    printf("\n\t\t----------------------\n");
    for(i=0; i<tam; i++)
    {
        if((dato+i)->estado==1)
        {
            mostrarPeli((dato+i));
            flag=1;
        }

    }
    if(flag==0)
    {
        printf("\n No hay peliculas registradas\n");


    }
}
//**************************************************************************
int BuscarPeli(eMovie *dato,int tam,int aux)
{
    int i,flag=0;
    int retorno;

    for(i=0; i<tam; i++)
    {

        if(aux==(dato+i)->id)
        {
            if((dato+i)->estado==1)
            {
                retorno=i;
                flag=1;
                break;

            }

        }
        if(flag==0)
        {
            retorno=-1;
        }
    }
    return retorno;
}

//**************************************************************************
void borrarPeli(eMovie* movie,int tam)
{
    int indice;
    int flag=0;
    int aux;
    char auxC[10];

    char respuesta='s';
    printf("\nPor favor ingrese el numero de indentificacion de la pelicula: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxC);
    isNumber(auxC);
    aux=atoi(auxC);
    indice=BuscarPeli(movie,tam,aux);
    while(indice==-1)
    {
        printf(" Pelicula inexistente\n");
        printf("\nPor favor Reingrese el numero de indentificacion de la pelicula: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxC);
        isNumber(auxC);
        aux=atoi(auxC);
        indice=BuscarPeli(movie,tam,aux);
    }

    printf(" Desea eliminar este Film?(s/n)\n %s \n",(movie+indice)->titulo);
    fflush(stdin);
    respuesta=getch();
    while(respuesta!='s'&&respuesta!='n')
    {
        printf("Por favor responda (s/n)\n");
        fflush(stdin);
        respuesta=getch();
        system("pause");
        system("cls");
    }
    if(respuesta=='s')
    {
        (movie+indice)->estado=0;
        printf("Pelicula eliminada con exito\n");


    }
    else
    {
        printf("\nAccion cancelada por el usuario\n");


    }


}
//*********************************************************************
void modificacionLetra(char confirm,char palabra[])
{
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea realizar la modificacion ? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        printf("\n Ingrese su modificacion: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",palabra);
        isWord(palabra);
        printf("\n Modificacion realizada con Exito\n");
    }
    else
    {
        printf("\nAccion cancelada por el Usuario");
    }
}
//*********************************************************************
void modificacionNum(char confirm,char palabra[])
{
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea realizar la modificacion ? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        printf("\n Ingrese su modificacion: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",palabra);
        isFloat(palabra);
        printf("\n Modificacion realizada con Exito\n");
    }
    else
    {
        printf("\nAccion cancelada por el Usuario");

    }
}
//*********************************************************************
void modificacion(char confirm,char palabra[])
{
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea realizar la modificacion ? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        printf("\n Ingrese su modificacion: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",palabra);
        printf("\n Modificacion realizada con Exito\n");
    }
    else
    {
        printf("\nAccion cancelada por el Usuario");

    }
}
//*********************************************************************

void ModificarPeli(eMovie* dato,int tam)
{
    int indice;
    int flag=0;
    int aux;
    int opcion;
    char auxC[10];
    char confirm;


    char respuesta='s';
    printf("\nPor favor ingrese el numero de indentificacion de la pelicula: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxC);
    isNumber(auxC);
    aux=atoi(auxC);
    indice=BuscarPeli(dato,tam,aux);
    while(indice==-1)
    {
        printf(" Pelicula inexistente\n");
        printf("\nPor favor Reingrese el numero de indentificacion de la pelicula: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxC);
        isNumber(auxC);
        aux=atoi(auxC);
        indice=BuscarPeli(dato,tam,aux);
    }
    do
    {
        printf("1-Modificar titulo\n");
        printf("2-Modificar genero\n");
        printf("3-Modificar duracion\n");
        printf("4-Modificar descripcion\n");
        printf("5-Modificar puntaje\n");
        printf("6-Modificar link\n");
        printf("7-Salir\n");
        printf("Ingrese una opcion: ");
        setbuf(stdin,NULL);
        scanf("%s",auxC);
        isNumber(auxC);
        opcion=atoi(auxC);
        switch(opcion)
        {
        case 1:
            printf("Titulo: %s\n",(dato+indice)->titulo);
            printf("Desea modificar el titulo de esta pelicula? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
            modificacionLetra(confirm,(dato+indice)->titulo);
             system("pause");
            system("cls");

            break;
        case 2:
            printf("Genero: %s\n",(dato+indice)->genero);
            printf("Desea modificar el genero de esta pelicula? [s/n] ");
            setbuf(stdin,NULL);
            confirm=getch();
            modificacionLetra(confirm,(dato+indice)->genero);
             system("pause");
            system("cls");

            break;
        case 3:
            printf("Duracion: %s\n",(dato+indice)->duracion);
            printf("Desea modificar la duracion de esta pelicula? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
            modificacionNum(confirm,(dato+indice)->duracion);
             system("pause");
            system("cls");


            break;
        case 4:
            printf("Descripcion: %s\n",(dato+indice)->descripcion);
            printf("Desea modificar la decripcion de esta pelicula? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
            modificacionLetra(confirm,(dato+indice)->descripcion);
             system("pause");
            system("cls");


            break;
        case 5:
            printf("Puntaje: %s\n",(dato+indice)->puntaje);
            printf("Desea modificar la decripcion de esta pelicula? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
            modificacionNum(confirm,(dato+indice)->puntaje);
             system("pause");
            system("cls");

            break;
        case 6:
            printf("Link: %s\n",(dato+indice)->link);
            printf("Desea modificar el link de esta pelicula? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
            modificacion(confirm,(dato+indice)->link);
            system("pause");
            system("cls");
            break;
        case 7:
            respuesta='n';
            break;

        default:
            printf("Ingrese una opcion entre 1-7\n");

            break;
        }

    }
    while(respuesta=='s');

}
//*****************************************************************
void guardarBinario(eMovie* movie,int tam)
{
    FILE* pPelis;
    pPelis=fopen("bin.dat","wb");
    if(pPelis==NULL)
    {
        printf("Error al abrir el archivo binario\n");
        exit(1);
    }
    fseek(pPelis,0L,SEEK_END);
    setbuf(stdin,NULL);
    fwrite(movie,sizeof(eMovie),tam,pPelis);
    printf("\nArchivo binario guardado con exito!\n");
    fclose(pPelis);
}
//****************************************************************
void GenerarPag(eMovie* movie,int tam)
{

    int i;
    FILE* PELI;

    PELI=fopen("C:peliculas.html","w+");
    if(PELI==NULL)
    {
        printf("\nError al abrir el archivo\n");
        exit(1);
    }
    for(i=0; i<tam; i++)
    {
        if((movie+i)->estado==1)
        {

            fprintf(PELI,"<article class='col-md-4 article-intro'>\
                    <a href='#'>\
                    <img class='img-responsive img-rounded' src='%s'\
                    alt=''>\
                    </a>\
                    <h3>\
                    <a href='#'>%s</a>\
                    </h3>\
                    <ul>\
                    <li>G�nero:%s</li>\
                    <li>Puntaje:%s</li>\
                    <li>Duraci�n:%s minutos</li>\
                    </ul>\
                    <p>%s.</p>\
                    </article>",(movie+i)->link,(movie+i)->titulo,(movie+i)->genero,(movie+i)->puntaje,(movie+i)->duracion,(movie+i)->descripcion);


        }


    }
    printf("\nArchivo creado con exito!\n");

    fclose(PELI);

}
//***********************************************************************
void salir(eMovie* dato,int tam)
{
    char respuesta;
    printf("\nDesea guardar los cambios realizados en el archivo ?? (s/n)\n");
    setbuf(stdin,NULL);
    respuesta=getch();

    while(respuesta!='n'&&respuesta!='s')
    {
        printf("ERROR");
        printf("\nDesea guardar los cambios realizados en el archivo ?? (s/n)\n");
        setbuf(stdin,NULL);
        respuesta=getch();
    }
    if(respuesta=='s')
    {
        guardarBinario(dato,tam);
    }

}
//******************************************************************
void validarDescripcion(char dato[])
{
    int tam;
    isWord(dato);
    tam=strlen(dato);
    while(atoi(dato)>=200)
    {
        printf("Ingrese una descripcion mas acotada de la Pelicula: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",dato);
        isWord(dato);

    }
}
//********************************************************************
void validarLink(char dato[])
{
    int tam;

    tam=strlen(dato);
    while(atoi(dato)>=200)
    {
        printf("Direccion inexistente ingrese un link valido: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",dato);


    }
}
//******************************************************************
void validarPuntaje(char dato[])
{
    isNumber(dato);
    while(atoi(dato)>10||atoi(dato<1))
    {
        printf("\nPor favor ingrese un puntaje entre (1-10)\n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",dato);
    }
}
