#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funciones.h"
#include <string.h>


int main()
{
    int opcion;
    char respuesta='s';
    char auxOP[30];
    int longitudP=1;
    eMovie *Auxmov;
    eMovie *peli;
    eMovie* auxMov;
    int NueLongitud;
    int tam;

     system("color C");
     printf("\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\tNETFLIX\n\n\n\n\n\n\n\n\n\n");
     printf("Si quiere ingresar: ");
     system("pause");
     system("cls");
     system("color 4F");

     peli=(eMovie*)malloc(sizeof(eMovie));
     peli = cargarBinario( peli, &tam );


    do
    {
        opcion=menu(auxOP);
        switch(opcion)
        {
        case 1:

            tam=AltaMovie(peli,tam,NueLongitud);
            tam++;
            Auxmov=realloc(peli,sizeof(eMovie)*tam);
            if(Auxmov!=NULL)
            {
                peli=Auxmov;
            }
            system("pause");
            system("cls");
            break;
        case 2:
             borrarPeli(peli,tam);

             system("pause");
            system("cls");

            break;
        case 3: ModificarPeli(peli,tam);


            system("pause");
            system("cls");
            break;
        case 4:
            GenerarPag(peli,tam);
            system("pause");
            system("cls");
            break;
        case 5:
            mostrarFILMS(peli,tam);

            system("pause");
            system("cls");
            break;
        case 6:
           guardarBinario(peli,tam);
            system("pause");
            system("cls");
            break;
        case 7:
            salir(peli,tam);
            respuesta='n';
            break;
        default:
            system("pause");
            system("cls");
            printf("Ingrese una opcion entre 1-7\n");

            break;
        }


    }
    while(respuesta=='s');

    return 0;
}

