#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <string.h>

typedef struct
{
    char titulo[30];
    char genero[30];
    char duracion[10];
    char descripcion[200];
    char puntaje[5];
    char link[200];
    int estado;
    int id;

}eMovie;

/**
 * Permite verificar si la cadena ingresada es un numero entero
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int verifNumero(char cad[]);
/**
 * Pide que se ingrese el array hasta que sea un numero entero
 * @param array de char
 * @return array validado
 */
void isNumber(char aux[]);
/**
 * Muestra las distintas opciones que va a contener el programa
 * @param array de char
 * @return retorna la opcion seleccionada
 */
int menu(char auxOP[]);
/**
 * Permite verificar si la cadena ingresada es un numero flotante
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int verifFloat(char cad[]);
/**
 * Pide que se ingrese el array hasta que sea un numero flotante
 * @param array de char
 * @return array validado
 */
void isFloat(char aux[]);
/**
 * Permite verificar si la cadena ingresada contiene solamente letras
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int EsLetra(char letras[]);
/**
 * Pide que se ingrese el array hasta que solamente este contenga letras
 * @param array de char
 * @return array validado
 */
void isWord(char aux[]);
/**
 * Permite verificar si la cadena ingresada contiene solamente letras y numeros
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int VefAphaandNumber(char aux[]);
/**
 * Pide que se ingrese el array hasta que solamente contenga letras y numeros
 * @param array de char
 * @return array validado
 */
void isAlphaNumber(char aux []);
/** \brief Modifica todo dato que solamente este compuesto por letras
  * \param un char que determiana si se hace la modificacion o no
  * \param el array el cual queremos modificar
  * \return el array modificado
  *
  */
void modificacionLetra(char confirm,char palabra[]);
/** \brief Modifica todo dato que solamente este compuesto por numeros
  * \param un char que determiana si se hace la modificacion o no
  * \param el array el cual queremos modificar
  * \return el array modificado
  *
  */
void modificacionNum(char confirm,char palabra[]);
/** \brief Modifica cualquir dato
  * \param un char que determiana si se hace la modificacion o no
  * \param el array el cual queremos modificar
  * \return el array modificado
  *
  */
void modificacion(char confirm,char palabra[]);
/**
 * Permite validar que lo que se ingrese este compuesto por letras y limita su extecion
 * @param array de char
 * @return el array validado
 */

void validarDescripcion(char dato[]);
/**
 * Permite limitar su extecion
 * @param array de char
 * @return el array validado
 */
void validarLink(char dato[]);
/**
 * Permite validar que lo que se ingrese este compuesto por numeros y se encuentre entre 1-10
 * @param array de char
 * @return el array validado
 */
void validarPuntaje(char dato[]);
/** \brief Carga los archivos desde un archivo binario leido
  * \param puntero a estructura de pelicula
  * \param puntero Longitud
  * \return el puntero a estructura cargado con los datos leidos
  *
  */
eMovie * cargarBinario(eMovie *movie, int *cantidad);
/**
 * Permite el ingreso de los datos de la pelicula
 * @param puntero a estructura de pelicula
 * @param tama�o
 * @param nuevo tama�o
 * @return la cantidad de peliculas
 */
int AltaMovie(eMovie *dato,int longitud,int nuevaLongitud);
/**
 * Permite mostrar una Pelicula
 * @param puntero a estructura de pelicula
 * @return Pelicula ingresada
 */
void mostrarPeli(eMovie *dato);
/**
 * Permite mostrar todos las peliculas cargadas hasta el momento
 * @param puntero a estructura de pelicula
 * @param Longitud
 * @return Todas las peliculas con sus respectvos datos cargados
 */
void mostrarFILMS(eMovie *dato,int tam);
/**
 * Permite buscar una pelicual en especial por su codigo
 * @param puntero a estructura de pelicula
 * @param Longitud
 * @param codigo de la pelicula
 * @return Todas las peliculas con sus respectvos datos cargados
 */
int BuscarPeli(eMovie *dato,int tam,int aux);
/**
 * Permite eliminar el registro de una pelicula
 * @param puntero a estructura de pelicula
 * @param Longitud
 * @return Si se produjo o no la eliminacion de la pelicula
 */
void borrarPeli(eMovie* movie,int tam);
/**
 * Permite modificar el registro de un usuario
 * @param puntero a estructura de pelicula
 * @param Longitud
 * @return Si se produjo o no la modificacion  de la pelicula
 */
void ModificarPeli(eMovie* dato,int tam);
/**\brief Guarda los datos cargados en un archivo binario
 * \param puntero a estructura de pelicula
 * \param longitud
 * \return void
 *
 */
void guardarBinario(eMovie* movie,int tam);
/**
 * Permite Generar una pagina web con los datos cargados hasta el momento
 * @param puntero a estructura de pelicula
 * @param Longitud del array
 * @return Pagina HTML con las peliculas cargadas
 */
void GenerarPag(eMovie* movie,int tam);
/**
 * Permite guardar los cambios efectuados en la aplicacion antes de salir
 * @param puntero a estructura de pelicula
 * @param Longitud
 * @return si se guardo el archivo correctamente
 */
void salir(eMovie* dato,int tam);


