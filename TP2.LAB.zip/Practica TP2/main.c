#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funciones.h"
#define TAM 31
#define ESC 27

int main()
{

    int opcion;
    char auxOP[2];
    int i,auxBaja;
    ePersona persona[TAM];
    system("Color 4E");

    char respuesta='s';
    inicializarEST(persona,TAM);
    do
    {   printf("\t\tREGISTRO DE USUARIOS\n\n");
        printf("1. Agregar una persona\n");
        printf("2. Borrar una persona\n");
        printf("3. Imprimir lista ordenada por nombre\n");
        printf("4. Imprimir grafico de edades\n");
        printf("5. Datos Harcodeados\n");
        printf("6. Salir\n");
        printf("Ingrese una opcion: ");
        setbuf(stdin,NULL);
        scanf("%s",auxOP);
        if(verifNumero(auxOP)==1)
        {
            opcion=atoi(auxOP);
        }

        switch(opcion)
        {
        case 1:
            if(ingresarPersona(persona,TAM)==0)
            {
                printf("No hay mas espacio disponible");
            }
            system("pause");
            system("cls");
            break;
        case 2:
            auxBaja=Baja(persona,TAM);
            if(auxBaja!=-1)
            {
                persona[auxBaja].estado=0;
                printf("\n Usuario eliminado con exito\n");

            }
            else
            {
                printf("\n ACCION CANCELADA\n ");
            }
            system("pause");
            system("cls");

            break;
        case 3:
            ordenarPersonas(persona,TAM);
            mostrarPERSONAS(persona,TAM);
            system("pause");
            system("cls");
            break;
        case 4:
            grafico(persona,TAM);
            system("pause");
            system("cls");
            break;
        case 5:
            HardCode(persona,TAM);
            system("pause");
            system("cls");
            break;
        case 6:
            respuesta='n';
            break;
        default:
            printf("Ingrese una opcion entre 1-5\n");
            system("pause");
            system("cls");

            break;
        }


    }
    while(respuesta=='s');
    return 0;
}



