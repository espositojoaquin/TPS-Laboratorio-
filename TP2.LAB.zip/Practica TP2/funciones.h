typedef struct
{
    char nombre[30];
    int edad;
    char dni[20];
    int estado;

}ePersona;
/**
 * Permite el registro de un nuevo usuario.
 * @param estructura de usuario
 * @param Tama�o de la estructura
 * @return 1 si se pudo cargar un nuevo Usuario y 0 si no hay mas espacio
 */
int ingresarPersona(ePersona gente[],int TAM);
/**
 * Inicializa todos los estados a 0
 * @param estructura de usuario
 * @param Tama�o de la estructura
 * @return Todos los estados inicializado
 */
void inicializarEST(ePersona gente[],int tam);
/**
 * Obtiene el primer indice libre del array.
 * @param estructura de usuario
 * @param Tama�o de estructura
 * @return el primer indice disponible
 */
int EspacioLibre(ePersona gente[],int tam);
/**
 * Permite mostrar el Usuario que fue ingresado
 * @param estructura de usuario
 * @return Usuario ingresado
 */
void mostrarPersona(ePersona gente);
/**
 * Permite listar los Usuarios en orden alfabetico
 * @param estructura de usuario
 * @param Tama�o de la estructura
 * @return lista de Usuarios ordenada alfabeticamente
 */
void ordenarPersonas(ePersona gente[],int tam);
/**
 * Permite mostrar todos los usuarios cargados hasta el momento
 * @param estructura de usuario
 * @param array de la estructura
 * @return Todos los Usuarios con sus respectvos datos cargados
 */
void mostrarPERSONAS(ePersona persona[],int tam);
/**
 * Permite eliminar el registro de un usuario
 * @param estructura de usuario
 * @param Tama�o de la estructura
 * @return En caso de encontrar al usuario retorna su posicion, de lo contrario retorno -1
*/
int Baja(ePersona gente[],int tam);
/**
 * Verifica si una cadena es numerica
 * @param cadena de caracteres
 * @return 1 En caso de ser un numero,0 en caso contrario
*/
int verifNumero(char cad[]);
/**
 * Permite delimitar la longitud que debe tener la cadena de caracteres
 * @param cadena de caracteres
 * @param maxima longitud de cadena
 * @return 1 si la palabra ingresada sobrepasa la longitud maxima,0 si no lo hace
*/
int LargoCad(char cad[],int tam);
/**
 * Permite pasar un elemnto de cadena a entero
 * @param cadena
 * @return el string en formato de entero
*/
int VEdad(char edad[]);
/**
 * Verifica que la edad sea mayor a 0 y menor a una edad ilogica
 * @param cadena
 * @return edad validada
 */
int validarEdad(char edad[]);
/**
 * muestra un grafico de barras respresentado el rango por edad de los usuarios
 * @param estructura de usuario
 * @param array de la estructura
 * @return Rango de edades representado en un grafico
 */
void grafico(ePersona persona[],int);
void HardCode(ePersona[],int tam);
/**
 * Cuenta la cantidad de usuarios que tienen 18 anios o menos
 * @param estructura de usuario
 * @param array de la estructura
 * @return Cantidad de Usuarios con 18 anios o menos
 */
int contador18(ePersona  [],int);
/**
 * Cuenta la cantidad de usuarios que tienen entre 19 y 35 anios
 * @param estructura de usuario
 * @param array de la estructura
 * @return Cantidad de Usuarios entre 19 y 35
 */
int contador19(ePersona [],int);
/**
 * Cuenta la cantidad de usuarios que tienen mas de 35 anios
 * @param estructura de usuario
 * @param array de la estructura
 * @return Cantidad de Usuarios con mas de 35 anios
 */
int contador35(ePersona [],int);
/**
 * Verifica de los 3 rangos de edades cual es el que predomina
 * @param contador de rango de 1-18
 * @param contador de rango de 19-35
 * @param contador de rango de mayores de 35
 * @return contador con la edad predominante
 */
int mayor(int cont18,int cont19,int cont35);
 /**
 * Verifica que el DNI se encuentre completo
 * @param string que contiene el DNI
 * @param Tama�o de la estructura
 * @param estructura de usuario
 * @return DNI validado
 */
int repetirDNI(char dni[],int tam,ePersona persona[]);
