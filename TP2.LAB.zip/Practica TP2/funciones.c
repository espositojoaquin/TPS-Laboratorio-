#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"

void inicializarEST(ePersona gente[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        gente[i].estado=0;

    }
}


//*******************************************************************************************************
int EspacioLibre(ePersona gente[],int tam)
{
    int i;
    int retorno;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==0)
        {
            retorno=i;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;
}
//*******************************************************************************************************



//*******************************************************************************************************

int ingresarPersona(ePersona gente[],int TAM)
{
    int i,flag=0;
    int indice;
    char auxEdad[10];


    indice=EspacioLibre(gente,TAM);
    if(indice!=-1)
    {

        printf("Por favor ingrese su nombre: \n");
        setbuf(stdin,NULL);
        gets(gente[indice].nombre);
        validarNombre(gente[indice].nombre);
        printf("Por favor ingrese su edad: \n");
        scanf("%s",auxEdad);
        gente[indice].edad=VEdad(auxEdad);
        printf("Por favor ingrese su DNI: \n");
        setbuf(stdin,NULL);
        scanf("%s",gente[indice].dni);
        validarDNI(gente[indice].dni,TAM,gente);

        gente[indice].estado=1;
        flag=1;

    }



    return flag;
}
//*******************************************************************************************************

int Baja(ePersona gente[],int tam)
{
    char DNI[20];
    int i,retorno,flag=0;
    int posicion;
    char respuesta;
    printf("Por favor ingrese el Dni de usuario que desea eliminar\n");
    setbuf(stdin,NULL);
    scanf("%s",DNI);
    for(i=0; i<tam; i++)
    {
        if(strcmpi(DNI,gente[i].dni)==0)
        {
            if(gente[i].estado!=0)
            {
             posicion=i;
             flag=1;
             break;
            }

        }

    }
    if(flag==0)
    {
        printf("El Dni ingresado es inexistente");
        retorno=-1;
    }
    else
    {
        printf("Desea elimiar este usuario? (s/n): \n");
        mostrarPersona(gente[posicion]);
        setbuf(stdin,NULL);
        scanf("%c",&respuesta);

        if(respuesta=='s')
        {
            retorno=posicion;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}

//********************************************************************************************************
void mostrarPersona(ePersona gente)
{

    printf("|%-15s\t\t%-10d\t\t%-15s|\n",gente.nombre,gente.edad,gente.dni);
}

//********************************************************************************************************

void ordenarPersonas(ePersona gente[],int tam)
{
    int i,j;
    ePersona auxiliar;
    for(i=0; i<tam-1; i++)
    {
        for(j=i+1; j<tam; j++)
        {
            if(gente[i].estado==1&&gente[j].estado==1)
            {
                if(strcmpi(gente[i].nombre,gente[j].nombre)>0)
                {
                    auxiliar=gente[i];
                    gente[i]=gente[j];
                    gente[j]=auxiliar;

                }
            }


        }
    }
}
//********************************************************************************************************

void mostrarPERSONAS(ePersona persona[],int tam)
{
    int i,flag=0;
    for(i=0; i<tam; i++)
    {
        if(persona[i].estado==1)
        {
            flag=1;
            if(i==0)
            {
                printf("|======================================================================|\n");
                printf("|                            USUARIOS                                  |\n");
                printf("|======================================================================|\n");
                printf("|   NOMBRE      |              EDAD        |          DOCUMENTO        |\n");
                printf("|======================================================================|\n");
            }

            mostrarPersona(persona[i]);
        }

    }
    if(flag==0)
    {
        printf("No hay Usuarios ingresados\n");
    }
}

//********************************************************************************************************

int verifNumero(char cad[])
{
    int tam;
    int i;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]>'9'||cad[i]<'0')
        {
            retorno=0;
            break;
        }
        else
        {
            retorno=1;
        }
    }
    return retorno;
}

//********************************************************************************************************
int LargoCad(char cad[],int tam)
{
    int auxNum,retorno;
    auxNum=strlen(cad);
    if(auxNum>tam)
    {
        retorno=1;
    }
    else
    {
        retorno=0;
    }
    return retorno;
}

//********************************************************************************************************
void validarDNI(char dni[],int tam,ePersona persona[])
{
    while(repetirDNI(dni,tam,persona))
    {
        printf("Este DNI fue ingresado por otro Usuario\n");
        printf("Por favor ingresar un DNI valido: ");
        setbuf(stdin,NULL);
        scanf("%s",dni);
    }
    while(verifNumero(dni)!=1||strlen(dni)!=8)
    {
        printf("Por favor ingresar un DNI valido: \n");
        setbuf(stdin,NULL);
        scanf("%s",dni);
    }
}
//********************************************************************************************************
int EsLetra(char letras[])
{
    int i,retorno;
    int tam=strlen(letras);
    strlwr(letras);

    for(i=0; i<tam; i++)
    {
        if(letras[i]<'a'&&letras[i]!=' '||letras[i]>'z'&&letras[i]!=' ')
        {
            retorno=0;
            break;
        }
        else
        {

            retorno=1;
            letras[0]=toupper(letras[0]);

        }
    }
    return retorno;
}
void validarNombre(char nombre[])
{
    while(EsLetra(nombre)==0)
    {
        printf("Por favor ingrese un nombre valido: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",nombre);

    }
}
int validarEdad(char edad[])
{
    int retorno;
    if(verifNumero(edad)==1&&strlen(edad)<3)
    {
        retorno=1;
    }
    else
    {
        retorno=0;
    }
    return retorno;

}
int VEdad(char edad[])
{
    int num;
    if(validarEdad(edad)==1)
    {
        num=atoi(edad);
        while(num==0)
        {
            printf("Ingrese una edad valida: ");
            setbuf(stdin,NULL);
            scanf("%s",edad);
            num=atoi(edad);
        }


    }
    else
    {
        while(validarEdad(edad)!=1)
        {
            printf("Ingrese una edad valida: ");
            setbuf(stdin,NULL);
            scanf("%s",edad);
            if(validarEdad(edad)==1)
            {
                num=atoi(edad);
                break;
            }
        }

    }
    return num;
}

int contador18(ePersona persona[],int tam)
{
    int i,cont=0;
    for(i=0; i<tam; i++)
    {
        if(persona[i].estado==1)
        {
            if(persona[i].edad<19)
            {
                cont++;
            }
        }

    }

    return cont;
}
int contador19(ePersona persona[],int tam)
{
    int i,cont=0;
    for(i=0; i<tam; i++)
    {
        if(persona[i].estado==1)
        {
            if(persona[i].edad>18&&persona[i].edad<36)
            {
                cont++;
            }
        }

    }

    return cont;
}
int contador35(ePersona persona[],int tam)
{
    int i,cont=0;
    for(i=0; i<tam; i++)
    {
        if(persona[i].estado==1)
        {
            if(persona[i].edad>35)
            {
                cont++;
            }
        }

    }

    return cont;
}

void grafico(ePersona gente[],int tam)
{
    int i;
    int cont18m;
    int cont19m;
    int cont35m;
    int flag1=0;
    int may;

    cont18m=contador18(gente,tam);
    cont19m=contador19(gente,tam);
    cont35m=contador35(gente,tam);
    may=mayor(cont18m,cont19m,cont35m);

    for(i=may; i>0; i--)
    {
        if(i<10)
        {
            printf("%02d|",i);
        }
        else
        {
            printf("%02d|",i);
        }

        if(i<=cont18m)
        {
            printf("*");
        }
        if(i<=cont19m)
        {
            flag1=1;
            printf("\t *");
        }
        if(i<=cont35m)
        {
            if(flag1==0)
            {
                printf("\t\t*");
            }
            else
            {
                if(flag1==1)
                {
                    printf("\t*");
                }
            }
        }
        printf("\n");
    }


    printf("--+-----------------");
    printf("\n |<18\t19-35\t>35 \n");
}
int mayor(int cont18m,int cont19m,int cont35m)
{
    int mayor;

    if(cont18m>=cont19m&&cont18m>=cont35m)
    {
        mayor=cont18m;
    }

    else
    {
        if(cont19m>=cont18m&&cont19m>=cont35m)
        {
            mayor=cont19m;
        }
        else
        {

            mayor=cont35m;
        }
    }
    return mayor;

}
int repetirDNI(char dni[],int tam,ePersona persona[])
{
    int i,retorno=0;

    for(i=0; i<tam; i++)
    {
        if(persona[i].estado==1)
        {
            if(strcmp(persona[i].dni,dni)==0)
            {
                retorno=1;

            }

        }

    }
    return retorno;

}
//**************************************************************************************************************
void HardCode(ePersona gente[],int tam)
{
    int edad[20]= {10,11,20,21,22,40,47,5,17,65,33,37,15,26,28,29,25,14,36,45};
    char nombre[20][50]= {"Juan","Maria","Pedro","Julian","Martina","Julio","Kevin","Joaquin","Leonel","Brenda","Aldana","Luz","Agustin","Angel","Brian","Gladys","Ruben","Luis","Claudia","Vanina"};
    char dni[20][20]= {"40929964","40929954","40929966","40929969","47929964","40929914","40929963","48929964","41929964","42929964","43929964","44929964","45929964","46929964","40129964","40229964","41329964","40929644","40926984","40929147"};
    int cont18m;
    int cont19m;
    int cont35m;

    int i;
    printf("\t\PERSONAS\n");

    for(i=0; i<20; i++)
    {
        strcpy(gente[i].dni,dni[i]);
        strcpy(gente[i].nombre,nombre[i]);
        gente[i].edad=edad[i];

        gente[i].estado=1;

    }
    cont18m=contador18(gente,tam);
    cont19m=contador19(gente,tam);
    cont35m=contador35(gente,tam);
    mostrarPERSONAS(gente,tam);


}

